# Aiva v4 - seekhne wala, animated JARVIS-style phone agent
- Seekhta hai: nicknames, pasand aaye jawab (👍/👎), kaam ke macros, aadatein; online se sikhaya hua offline model ko misaal banta hai
- Animated orb, aurora background, typing dots, floating draggable HUD
- Offline (MediaPipe Gemma) ya Online (Gemini / Claude) dimaag
