package com.example.aiva

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Aiva ka dimaag: Offline (phone par) ya Online (Gemini / Claude API). */
interface Brain {
    fun ready(): String?
    fun chat(system: String, turns: List<Pair<Boolean, String>>, maxChars: Int, examples: List<Pair<String, String>>, onPartial: (String) -> Unit): String
    fun decide(system: String, user: String): String
    fun stop()
}

class LocalBrain(private val llm: LlmEngine) : Brain {
    override fun ready(): String? =
        if (llm.hasModel()) null else "Pehle AI model file chunein (⚙ dabayein), ya Online brain ON karein."

    override fun chat(system: String, turns: List<Pair<Boolean, String>>, maxChars: Int, examples: List<Pair<String, String>>, onPartial: (String) -> Unit): String =
        llm.ask(Prompts.chat(system, turns, llm.chatBudget, examples), maxChars, null, onPartial)

    override fun decide(system: String, user: String): String {
        val prefix = "{\"action\":\""
        val prompt = "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n$prefix"
        val r = llm.ask(prompt, 300, '}') { }
        return if (r.isBlank()) "" else prefix + r
    }

    override fun stop() { llm.stopNow() }
}

class CloudBrain(private val prefs: SharedPreferences) : Brain {
    @Volatile private var conn: HttpURLConnection? = null

    override fun ready(): String? =
        if (prefs.getString("apikey", "").isNullOrBlank()) "Online brain ke liye ⚙ me API key daalein." else null

    override fun chat(system: String, turns: List<Pair<Boolean, String>>, maxChars: Int, examples: List<Pair<String, String>>, onPartial: (String) -> Unit): String {
        val out = call(system, merge(turns), if (maxChars > 800) 1400 else if (maxChars > 400) 700 else 350)
        onPartial(out)
        return out
    }

    override fun decide(system: String, user: String): String = call(system, listOf(true to user), 500)

    override fun stop() { try { conn?.disconnect() } catch (_: Exception) {} }

    private fun merge(turns: List<Pair<Boolean, String>>): List<Pair<Boolean, String>> {
        val out = ArrayList<Pair<Boolean, String>>()
        for ((u, t) in turns) {
            if (out.isNotEmpty() && out.last().first == u) out[out.size - 1] = u to (out.last().second + "\n" + t)
            else out.add(u to t)
        }
        while (out.isNotEmpty() && !out[0].first) out.removeAt(0)
        return out
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.doOutput = true
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw Exception("API error $code: " + text.take(220))
            return text
        } finally {
            try { c.disconnect() } catch (_: Exception) {}
            conn = null
        }
    }

    private fun call(system: String, msgs: List<Pair<Boolean, String>>, maxOut: Int): String {
        val provider = prefs.getString("provider", "gemini") ?: "gemini"
        val key = (prefs.getString("apikey", "") ?: "").trim()
        val model = (prefs.getString("cloudmodel", "") ?: "").trim()
            .ifBlank { if (provider == "claude") "claude-haiku-5-5" else "gemini-flash-latest" }
        val body = JSONObject()
        val headers = mutableMapOf("Content-Type" to "application/json")
        val url: String
        if (provider == "claude") {
            url = "https://api.anthropic.com/v1/messages"
            headers["x-api-key"] = key
            headers["anthropic-version"] = "2023-06-01"
            body.put("model", model).put("max_tokens", maxOut).put("system", system)
            val arr = JSONArray()
            for ((u, t) in msgs) arr.put(JSONObject().put("role", if (u) "user" else "assistant").put("content", t))
            body.put("messages", arr)
        } else {
            url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
            headers["x-goog-api-key"] = key
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            val arr = JSONArray()
            for ((u, t) in msgs) {
                arr.put(JSONObject().put("role", if (u) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            body.put("contents", arr)
            body.put("generationConfig", JSONObject().put("maxOutputTokens", maxOut + 2000).put("temperature", 0.7))
        }
        val resp = JSONObject(post(url, headers, body.toString()))
        val sb = StringBuilder()
        if (provider == "claude") {
            val arr = resp.getJSONArray("content")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "text") sb.append(o.optString("text"))
            }
        } else {
            val cands = resp.optJSONArray("candidates")
            if (cands == null || cands.length() == 0) throw Exception("Jawab nahi aaya (block ho gaya ho sakta hai)")
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim()
    }
}
