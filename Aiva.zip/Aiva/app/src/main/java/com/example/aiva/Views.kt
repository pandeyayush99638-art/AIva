package com.example.aiva

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Aiva ka jeevit orb: idle me saans leta hai, sunte waqt ripples, sochte waqt ghoomta arc, bolte waqt pulse. */
class OrbView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var phase = 0f
    private var state = 0
    private var color = Color.parseColor("#8B6CFF")
    private var colorAnim: ValueAnimator? = null
    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!loop.isStarted) loop.start() }
    override fun onDetachedFromWindow() { loop.cancel(); super.onDetachedFromWindow() }

    fun setState(s: Int) {
        state = s
        val target = Color.parseColor(when (s) { 1 -> "#2ECC71"; 2 -> "#FFB020"; 3 -> "#3DA5FF"; else -> "#8B6CFF" })
        colorAnim?.cancel()
        colorAnim = ValueAnimator.ofObject(ArgbEvaluator(), color, target).apply {
            duration = 450
            addUpdateListener { color = it.animatedValue as Int }
            start()
        }
    }

    private fun a(c: Int, alpha: Int): Int = Color.argb(alpha.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f
        val t = (phase * 2 * PI).toFloat()
        var core = base * 0.40f
        p.shader = null
        when (state) {
            1 -> {
                for (i in 0..2) {
                    val q = (phase + i / 3f) % 1f
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = base * 0.04f
                    p.color = a(color, ((1f - q) * 170).toInt())
                    c.drawCircle(cx, cy, core + (base - core) * q, p)
                }
                core *= 1f + 0.04f * sin(t * 3)
            }
            3 -> {
                core *= 1f + (0.10f + 0.06f * sin(t * 5)) * sin(t * 6)
                for (i in 1..2) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = base * 0.035f
                    p.color = a(color, 110 - i * 35)
                    c.drawCircle(cx, cy, core + base * 0.14f * i * (1f + 0.35f * sin(t * 4 + i)), p)
                }
            }
            2 -> {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = base * 0.07f
                oval.set(cx - core * 1.35f, cy - core * 1.35f, cx + core * 1.35f, cy + core * 1.35f)
                p.color = a(color, 230)
                c.drawArc(oval, phase * 720f, 95f, false, p)
                p.color = a(color, 120)
                c.drawArc(oval, phase * 720f + 180f, 60f, false, p)
                p.strokeCap = Paint.Cap.BUTT
                core *= 1f + 0.03f * sin(t * 4)
            }
            else -> core *= 1f + 0.05f * sin(t)
        }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, core * 2.1f, intArrayOf(a(color, 110), a(color, 0)), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, core * 2.1f, p)
        p.shader = RadialGradient(cx - core * 0.3f, cy - core * 0.35f, core * 1.4f,
            intArrayOf(ColorUtils.blendARGB(color, Color.WHITE, 0.55f), color), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, core, p)
        p.shader = null
    }
}

/** Dheere behta hua aurora background. */
class AuroraView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 26000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!loop.isStarted) loop.start() }
    override fun onDetachedFromWindow() { loop.cancel(); super.onDetachedFromWindow() }
    fun pauseAnim() { if (loop.isRunning) loop.pause() }
    fun resumeAnim() { if (loop.isPaused) loop.resume() }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: String, alpha: Int) {
        val b = Color.parseColor(col)
        p.shader = RadialGradient(x, y, r,
            intArrayOf(Color.argb(alpha, Color.red(b), Color.green(b), Color.blue(b)), Color.argb(0, Color.red(b), Color.green(b), Color.blue(b))),
            null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#0A0A1C"))
        val w = width.toFloat()
        val h = height.toFloat()
        val a = (t * 2 * PI).toFloat()
        blob(c, w * (0.2f + 0.15f * sin(a)), h * (0.18f + 0.08f * cos(a * 1.3f)), w * 0.75f, "#6B4DFF", 95)
        blob(c, w * (0.85f + 0.10f * cos(a * 0.8f)), h * (0.45f + 0.12f * sin(a)), w * 0.70f, "#2B8CFF", 70)
        blob(c, w * (0.4f + 0.2f * sin(a * 0.6f)), h * (0.92f + 0.05f * cos(a)), w * 0.80f, "#B23CFF", 60)
    }
}

/** "Aiva soch raha hai" ke 3 uchhalte dots. */
class DotsView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B9B6E8") }
    private var t = 0f
    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 900
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!loop.isStarted) loop.start() }
    override fun onDetachedFromWindow() { loop.cancel(); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        val d = resources.displayMetrics.density
        setMeasuredDimension((46 * d).toInt(), (24 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        for (i in 0..2) {
            val ph = (t + i * 0.18f) % 1f
            val s = sin(ph * PI).toFloat()
            p.alpha = (140 + 115 * s).toInt()
            c.drawCircle(width * (0.2f + 0.3f * i), height / 2f - s * 5f * d, 3.2f * d, p)
        }
    }
}

/** Dabane par chhota "press" animation. */
fun View.pressAnim() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}
