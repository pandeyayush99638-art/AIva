package com.example.aiva

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.text.TextUtils
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Aiva ki aankhein aur haath: screen padhta hai, tap/type/swipe karta hai, HUD dikhata hai. */
class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        const val HUD_WORK = 0
        const val HUD_ASK = 1
        const val HUD_OK = 2
        const val HUD_ERR = 3
    }

    @Volatile var stopRequested = false
    @Volatile var lastPkg = ""
    private var nodes = listOf<AccessibilityNodeInfo>()
    private val main = Handler(Looper.getMainLooper())
    private var hudRoot: LinearLayout? = null
    private var hudDot: View? = null
    private var hudText: TextView? = null
    private var hudStop: TextView? = null
    private var hudPulse: ValueAnimator? = null
    private var onTapBody: (() -> Unit)? = null
    private var hudToken = 0
    private var lastVol = 0L
    private val risky = Regex(
        "pay|buy|purchase|delete|remove|send|transfer|place order|confirm|submit|bhejo|भेज|हटा|खरीद|पेमेंट|भुगतान",
        RegexOption.IGNORE_CASE)

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { hideHud(); instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Volume-down 2 baar jaldi dabao = emergency stop. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            val now = System.currentTimeMillis()
            if (now - lastVol < 700) stopRequested = true
            lastVol = now
        }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text ?: n.contentDescription ?: n.hintText ?: "").toString().replace("\n", " ").take(50)

    // ---------------- Screen padhna ----------------
    fun readScreen(): String {
        var root: AccessibilityNodeInfo? = null
        for (i in 0 until 4) {
            root = rootInActiveWindow
            if (root != null) break
            Thread.sleep(300)
        }
        val r = root ?: return "(screen padhi nahi ja saki)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (list.size >= 40 || depth > 25) return
            val useful = label(n).isNotBlank() || n.isClickable || n.isEditable || n.isCheckable
            if (useful && n.isVisibleToUser) list.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(r, 0)
        nodes = list
        lastPkg = (r.packageName ?: "").toString()
        val body = list.mapIndexed { i, n ->
            val tags = mutableListOf<String>()
            if (n.isClickable) tags.add("tap")
            if (n.isEditable) tags.add("input")
            if (n.isScrollable) tags.add("scroll")
            if (n.isCheckable) tags.add(if (n.isChecked) "ON" else "OFF")
            "[$i] ${label(n)} {${tags.joinToString(",")}}"
        }.joinToString("\n")
        return "APP: $lastPkg\n" + body.ifBlank { "(is screen par padhne layak kuch nahi, game ya WebView ho sakta hai)" }
    }

    // ---------------- Actions ----------------
    private fun tapXY(x: Float, y: Float): Boolean {
        val p = Path(); p.moveTo(x, y)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private fun click(n: AccessibilityNodeInfo, l: String, action: Int, ok: String): String {
        var t: AccessibilityNodeInfo? = n
        while (t != null && !(if (action == AccessibilityNodeInfo.ACTION_CLICK) t.isClickable else t.isLongClickable)) t = t.parent
        val target = t ?: n
        if (target.performAction(action)) return "$ok '$l'"
        val r = Rect(); n.getBoundsInScreen(r)
        return if (tapXY(r.centerX().toFloat(), r.centerY().toFloat())) "$ok '$l' (gesture)" else "Tap fail '$l'"
    }

    fun tap(id: Int, force: Boolean = false): String {
        val n = nodes.getOrNull(id) ?: return "No such element $id"
        val l = label(n)
        if (!force && risky.containsMatchIn(l)) return "CONFIRM:$l"
        return click(n, l, AccessibilityNodeInfo.ACTION_CLICK, "Tapped")
    }

    fun longPress(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "No such element $id"
        return click(n, label(n), AccessibilityNodeInfo.ACTION_LONG_CLICK, "Long-pressed")
    }

    fun type(id: Int, text: String, submit: Boolean): String {
        var n: AccessibilityNodeInfo? = nodes.getOrNull(id)
        if (n == null || !n.isEditable) {
            n = nodes.firstOrNull { it.isEditable } ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        }
        val target = n ?: return "Koi input box nahi mila"
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            try { target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) } catch (_: Throwable) {}
        }
        return if (ok) "Typed" + (if (submit) " + Enter" else "") else "Type fail"
    }

    fun swipe(dir: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "up" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "down" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return "Unknown direction"
        }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build()
        return if (dispatchGesture(g, null, null)) "Swiped $dir" else "Swipe fail"
    }

    fun scroll(dir: String): String {
        val n = nodes.firstOrNull { it.isScrollable }
        val act = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        if (n != null && n.performAction(act)) return "Scrolled $dir"
        return swipe(if (dir == "up") "down" else "up")
    }

    fun back(): String { performGlobalAction(GLOBAL_ACTION_BACK); return "Back" }
    fun home(): String { performGlobalAction(GLOBAL_ACTION_HOME); return "Home" }
    fun recents(): String { performGlobalAction(GLOBAL_ACTION_RECENTS); return "Recents" }
    fun notifications(): String { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); return "Notifications" }
    fun screenshot(): String =
        if (Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)) "Screenshot le liya." else "Screenshot nahi ho paaya."

    fun launchPackage(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    fun openApp(name: String): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        for (cand in Aliases.candidates(name)) {
            val c = cand.lowercase()
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == c }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().startsWith(c) }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(c) }
            if (hit != null && launchPackage(hit.activityInfo.packageName)) return "Opened ${hit.loadLabel(pm)}"
        }
        return "'$name' naam ka app nahi mila"
    }

    // ---------------- Helpers for learning ----------------
    fun labelOf(id: Int): String = nodes.getOrNull(id)?.let { label(it) } ?: ""

    fun indexOfLabel(l: String): Int {
        if (l.isBlank()) return -1
        val low = l.lowercase().trim()
        val exact = nodes.indexOfFirst { label(it).lowercase().trim() == low }
        if (exact >= 0) return exact
        return nodes.indexOfFirst {
            val x = label(it).lowercase().trim()
            x.length >= 3 && (x.contains(low) || low.contains(x))
        }
    }

    fun appExists(name: String): Boolean {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return Aliases.candidates(name).any { c -> apps.any { it.loadLabel(pm).toString().lowercase().contains(c.lowercase()) } }
    }

    // ---------------- HUD (floating, draggable, animated pill) ----------------
    private fun buildHud(wm: WindowManager) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        root.setPadding(dp(14), dp(9), dp(8), dp(9))
        root.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#F2231A5C"), Color.parseColor("#F23B2A99"))).apply {
            cornerRadius = dp(26).toFloat(); setStroke(dp(1), Color.parseColor("#55FFFFFF"))
        }
        root.elevation = dp(8).toFloat()

        val dot = View(this)
        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#A58BFF")) }
        root.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(10) })

        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.6f).toInt()
        root.addView(tv)

        val stop = TextView(this)
        stop.text = "⏹"
        stop.textSize = 14f
        stop.setTextColor(Color.WHITE)
        stop.gravity = Gravity.CENTER
        stop.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#55FFFFFF")) }
        stop.setOnClickListener { stopRequested = true }
        root.addView(stop, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(10) })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(24)
        lp.y = dp(90)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    try { wm.updateViewLayout(root, lp) } catch (_: Throwable) {}
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTapBody?.invoke(); true }
                else -> false
            }
        }

        wm.addView(root, lp)
        root.alpha = 0f
        root.translationY = -dp(40).toFloat()
        root.scaleX = 0.9f; root.scaleY = 0.9f
        root.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(300)
            .setInterpolator(OvershootInterpolator(1.1f)).start()
        hudRoot = root; hudDot = dot; hudText = tv; hudStop = stop
    }

    fun hud(msg: String, state: Int = HUD_WORK, onTap: (() -> Unit)? = null) {
        main.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                if (hudRoot == null) buildHud(wm)
                hudToken++
                onTapBody = onTap
                val t = hudText
                if (t != null && t.text.toString() != msg) {
                    t.animate().cancel()
                    t.alpha = 0f
                    t.translationY = 8f
                    t.text = msg
                    t.animate().alpha(1f).translationY(0f).setDuration(180).start()
                }
                val color = when (state) { HUD_ASK -> "#FFB020"; HUD_OK -> "#2ECC71"; HUD_ERR -> "#FF5A5F"; else -> "#A58BFF" }
                (hudDot?.background as? GradientDrawable)?.setColor(Color.parseColor(color))
                hudStop?.visibility = if (state == HUD_WORK || state == HUD_ASK) View.VISIBLE else View.GONE
                hudPulse?.cancel()
                val dot = hudDot
                if (dot != null) {
                    if (state == HUD_OK || state == HUD_ERR) {
                        dot.scaleX = 0.4f; dot.scaleY = 0.4f
                        dot.animate().scaleX(1.4f).scaleY(1.4f).setDuration(280).setInterpolator(OvershootInterpolator()).start()
                    } else {
                        hudPulse = ValueAnimator.ofFloat(0.8f, 1.3f).apply {
                            duration = 650
                            repeatMode = ValueAnimator.REVERSE
                            repeatCount = ValueAnimator.INFINITE
                            addUpdateListener { dot.scaleX = it.animatedValue as Float; dot.scaleY = it.animatedValue as Float }
                            start()
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun hudDone(msg: String, ok: Boolean, onTap: () -> Unit) {
        hud((if (ok) "Ho gaya · " else "Ruk gaya · ") + msg.take(46) + "  (tap)", if (ok) HUD_OK else HUD_ERR) { onTap(); hideHud() }
        val token = hudToken
        main.postDelayed({ if (token == hudToken) hideHud() }, 12000)
    }

    fun hideHud() {
        main.post {
            val v = hudRoot ?: return@post
            hudPulse?.cancel()
            hudRoot = null; hudDot = null; hudText = null; hudStop = null
            v.animate().alpha(0f).translationY(-30f).setDuration(200).withEndAction {
                try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Throwable) {}
            }.start()
        }
    }
}
