package com.example.aiva

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * On-device model. Har sawal ke liye NAYA session banta hai (saaf memory), jawab stream hota hai,
 * aur lamba/bakwaas jawab cancel ho jata hai. Ek saath sirf ek generation chalta hai.
 */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private val prefs = ctx.getSharedPreferences("aiva", Context.MODE_PRIVATE)
    private val busy = AtomicBoolean(false)
    @Volatile var wantStop = false

    val modelFile: File get() = File(ctx.filesDir, "model.task")
    fun hasModel(): Boolean = modelFile.exists() && modelFile.length() > 1_000_000

    private val safe: Boolean get() = prefs.getBoolean("safe", false)
    private val maxTokens: Int get() = if (safe) 768 else 1536
    val chatBudget: Int get() = if (safe) 1100 else 2000

    @Synchronized
    fun load() {
        if (llm != null) return
        prefs.edit().putString("inflight", "load").commit()
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile.absolutePath)
            .setMaxTokens(maxTokens)
            .build()
        llm = LlmInference.createFromOptions(ctx, opts)
        prefs.edit().remove("inflight").putInt("fails", 0).commit()
    }

    fun reset() {
        try { (llm as? AutoCloseable)?.close() } catch (_: Throwable) {}
        llm = null
    }

    fun stopNow() { wantStop = true }

    private fun cancel(s: LlmInferenceSession): Boolean = try {
        s.javaClass.getMethod("cancelGenerateResponseAsync").invoke(s); true
    } catch (e: Throwable) { false }

    private fun closeQuietly(s: LlmInferenceSession?) {
        try { (s as? AutoCloseable)?.close() } catch (_: Throwable) {}
    }

    /** Blocking (background thread se chalayein). Khaali string = engine busy raha. */
    fun ask(prompt: String, maxChars: Int, stopAt: Char?, onPartial: (String) -> Unit): String {
        var waited = 0
        while (!busy.compareAndSet(false, true)) {
            if (waited >= 60_000) return ""
            Thread.sleep(150); waited += 150
        }
        var session: LlmInferenceSession? = null
        var handedOff = false
        try {
            load()
            wantStop = false
            val sOpts = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                .setTopK(40)
                .setTemperature(0.7f)
                .build()
            val s = LlmInferenceSession.createFromOptions(llm!!, sOpts)
            session = s
            s.addQueryChunk(prompt)
            val sb = StringBuilder()
            val done = CountDownLatch(1)
            var capped = false
            prefs.edit().putString("inflight", "gen").commit()
            s.generateResponseAsync { partial, fin ->
                if (!capped) {
                    sb.append(partial ?: "")
                    onPartial(sb.toString())
                    val hit = stopAt != null && sb.indexOf(stopAt.toString()) >= 0
                    if (hit || sb.length > maxChars) { capped = true; wantStop = true }
                }
                if (fin) done.countDown()
            }
            val start = System.currentTimeMillis()
            var cancelAt = 0L
            while (!done.await(60, TimeUnit.MILLISECONDS)) {
                val now = System.currentTimeMillis()
                if (wantStop && cancelAt == 0L) { cancelAt = now; cancel(s) }
                if (cancelAt != 0L && now - cancelAt > 3500) break
                if (now - start > 180_000) break
            }
            if (done.count > 0L) {
                // Generation abhi chal raha hai (cancel support nahi): jawab abhi lauta do, safai peeche karo.
                handedOff = true
                Thread {
                    try { done.await(240, TimeUnit.SECONDS) } catch (_: Exception) {}
                    closeQuietly(s)
                    prefs.edit().remove("inflight").commit()
                    busy.set(false)
                }.start()
            }
            return sb.toString()
        } finally {
            if (!handedOff) {
                closeQuietly(session)
                prefs.edit().remove("inflight").commit()
                busy.set(false)
            }
        }
    }
}
