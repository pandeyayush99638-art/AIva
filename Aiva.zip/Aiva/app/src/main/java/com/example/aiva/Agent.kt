package com.example.aiva

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Phone control. Simple kaam turant (bina AI), mushkil kaam brain ke saath, aur kaam seekhta bhi hai. */
class Agent(
    private val ctx: Context,
    private val brain: () -> Brain,
    private val memory: Memory,
    private val learn: Learn,
    private val log: (String) -> Unit
) {
    @Volatile var stop = false

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    private val fillers = setOf(
        "mere", "mera", "meri", "phone", "me", "mein", "ka", "ki", "ke", "ko", "ek", "zara", "please", "plz",
        "app", "apps", "the", "my", "a", "jao", "par", "pe", "kar", "karo", "do", "de", "dena", "dijiye", "kijiye", "ab", "abhi")
    private val openVerbs = listOf(
        "open karo", "open kar do", "open", "launch", "start", "kholo", "khol do", "khol de", "kholiye", "khol",
        "chalao", "chalu karo", "खोल दो", "खोलो", "खोलिए", "चलाओ", "चालू करो")
    private val complexMarkers = rx("\\b(aur|and|then|phir|fir|baad me|after|search|likho|bhejo|send|type|play)\\b|और|फिर")
    private val slowActions = setOf("open_app", "web_search", "youtube", "maps", "call", "sms", "whatsapp", "email")

    private fun parseOpen(t: String): String? {
        val low = t.lowercase().trim()
        if (complexMarkers.containsMatchIn(low)) return null
        var rest: String? = null
        for (v in openVerbs.sortedByDescending { it.length }) {
            if (low.startsWith("$v ")) { rest = low.removePrefix("$v ").trim(); break }
            if (low.endsWith(" $v")) { rest = low.removeSuffix(" $v").trim(); break }
        }
        val r = rest ?: return null
        val tokens = r.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty() || tokens.size > 5) return null
        return tokens.filter { it !in fillers }.ifEmpty { tokens }.joinToString(" ")
    }

    /** Contact dhundo; na mile to ek baar poochho aur nickname yaad rakho. */
    private suspend fun resolveContact(nameRaw: String, ask: suspend (String) -> String, tools: Tools): Contact? {
        val name = nameRaw.trim()
        learn.alias("contact", name)?.let { a -> tools.lookup(a)?.let { return it } }
        tools.lookup(name)?.let { return it }
        if (!tools.hasContactsPerm()) return null
        val ans = ask("'$name' naam ka contact nahi mila. Contact me wo kis naam se save hai? (naam batayein, ya 'nahi')").trim()
        if (ans.isBlank() || Skills.isNo(ans)) return null
        val c = tools.lookup(ans) ?: return null
        learn.setAlias("contact", name, ans)
        return c
    }

    private suspend fun doCall(nameRaw: String, ask: suspend (String) -> String, tools: Tools): String {
        val name = nameRaw.split(" ").filter { it !in fillers }.joinToString(" ").ifBlank { nameRaw }
        val c = resolveContact(name, ask, tools)
            ?: return if (!tools.hasContactsPerm()) "Contacts ki permission chahiye. ⚙ dabakar permission dein." else "'$name' ka contact nahi mila."
        val yes = ask("${c.name} (${c.number}) ko call karun? (haan/nahi)")
        return if (Skills.isYes(yes)) tools.call(c.number) + " " + c.name else "Theek hai, call nahi kiya."
    }

    /** Turant wale commands. Jawab text ya null (null = brain se poochho). */
    suspend fun quick(raw: String, ask: suspend (String) -> String, localChat: Boolean): String? {
        val t = raw.trim().trimEnd('.', '!', '?', '।').trim()
        val low = t.lowercase()

        // "mummy matlab Sunita" -> nickname seekho
        rx("^(?:yaad rakho\\s+|remember\\s+)?(.+?)\\s+(?:matlab|means|ka matlab|ko samjho|yaani)\\s+(.+)$").find(t)?.let { m ->
            val a = m.groupValues[1].trim()
            val b2 = m.groupValues[2].trim()
            val question = rx("^(kya|kaun|kab|kahan|kyun|kaise|what|how|why)\\b")
            if (a.isNotBlank() && b2.isNotBlank() && a.split(" ").size <= 3 && b2.split(" ").size <= 4 &&
                !question.containsMatchIn(b2) && a.lowercase() !in setOf("iska", "uska", "is", "isse", "ye", "yeh")) {
                val s0 = AgentService.instance
                if (s0 != null && s0.appExists(b2)) learn.setAlias("app", a, b2) else learn.setAlias("contact", a, b2)
                return "Theek hai, ab '$a' ka matlab '$b2' samjhunga."
            }
        }

        Skills.answer(ctx, t, memory, localChat)?.let { return it }
        val svc = AgentService.instance ?: return null
        val tools = Tools(svc)

        if (rx("^(back|go back|wapas jao|wapas|peeche jao|peeche|पीछे जाओ|वापस जाओ|वापस)$").matches(low)) { svc.back(); return "Peeche aa gaya." }
        if (rx("^(home|go home|home jao|ghar jao|होम|होम जाओ)$").matches(low)) { svc.home(); return "Home screen par hoon." }
        if (rx("(screenshot|स्क्रीनशॉट)").containsMatchIn(low)) return svc.screenshot()
        if (rx("^(notifications?|notification (dikhao|kholo)|नोटिफिकेशन)").containsMatchIn(low)) { svc.notifications(); return "Notifications dikha diye." }
        if (rx("(torch|flashlight|फ्लैशलाइट|टॉर्च)").containsMatchIn(low)) {
            val on = !rx("(off|band|बंद|bujha)").containsMatchIn(low)
            return tools.flashlight(on)
        }
        if (low.contains("volume") || low.startsWith("awaaz") || low.startsWith("आवाज")) {
            val mode = when {
                rx("(mute|silent|chup|म्यूट)").containsMatchIn(low) -> "mute"
                rx("(full|max)").containsMatchIn(low) -> "max"
                rx("(badha|zyada|up|increase|बढ़ा)").containsMatchIn(low) -> "up"
                rx("(kam|ghata|down|decrease|घटा|कम)").containsMatchIn(low) -> "down"
                else -> null
            }
            if (mode != null) return tools.volume(mode)
        }

        rx("^(?:call|dial|phone)\\s+(?:to\\s+)?(.+)$").find(t)?.let { return doCall(it.groupValues[1], ask, tools) }
        rx("^(.+?)\\s+(?:ko\\s+)?(?:call|phone|fone|कॉल|फोन)(?:\\s+(?:karo|kar do|kardo|lagao|laga do|करो|लगाओ))?$").find(t)?.let {
            if (it.groupValues[1].split(" ").size <= 3) return doCall(it.groupValues[1], ask, tools)
        }

        val yq = rx("^youtube\\s+(?:par|pe|me|mein)\\s+(.+?)(?:\\s+(?:chalao|dikhao|play karo|lagao|search karo|sunao))?$").find(t)?.groupValues?.get(1)
            ?: rx("^(.+?)\\s+youtube\\s+(?:par|pe|me|mein)\\s*(?:chalao|dikhao|play karo|lagao|search karo)?$").find(t)?.groupValues?.get(1)
            ?: rx("^play\\s+(.+?)(?:\\s+on\\s+youtube)?$").find(t)?.groupValues?.get(1)
        if (yq != null) return if (tools.youtube(yq.trim())) "YouTube par '${yq.trim()}' khol diya." else "YouTube nahi khula."

        if (!low.contains("youtube")) {
            val sq = rx("^(?:(?:google|chrome)\\s+(?:par|pe|me|mein)\\s+)?(?:search for|search|dhundo|khojo|google)\\s+(.+)$").find(t)?.groupValues?.get(1)
                ?: rx("^(.+?)\\s+(?:search karo|search kar do|search kar|dhundo|khojo|google karo|सर्च करो|खोजो|ढूंढो)$").find(t)?.groupValues?.get(1)
            if (sq != null) return if (tools.webSearch(sq.trim())) "Google par '${sq.trim()}' search kar diya." else "Browser nahi khula."
        }

        if (rx("\\b(alarm|अलार्म)\\b").containsMatchIn(t)) {
            val m = rx("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|baje|बजे)?").find(t)
            if (m != null) {
                var h = m.groupValues[1].toInt()
                val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                val ap = m.groupValues[3].lowercase()
                if (ap == "pm" && h < 12) h += 12
                if (ap == "am" && h == 12) h = 0
                if (rx("(shaam|sham|raat|evening|night|शाम|रात)").containsMatchIn(t) && h < 12) h += 12
                if (h in 0..23 && mi in 0..59) return tools.alarm(h, mi, "Aiva")
            }
        }
        if (rx("\\b(timer|टाइमर)\\b").containsMatchIn(t)) {
            val m = rx("(\\d+)\\s*(minute|min|mins|मिनट|second|sec|सेकंड|ghanta|hour|घंटा)").find(t)
            if (m != null) {
                val n = m.groupValues[1].toInt()
                val u = m.groupValues[2].lowercase()
                val secs = if (u.startsWith("sec") || u.startsWith("सेक")) n else if (u.startsWith("h") || u.startsWith("g") || u.startsWith("घ")) n * 3600 else n * 60
                return tools.timer(secs)
            }
        }

        // App kholna (na mile to poochho aur nickname seekho)
        parseOpen(t)?.let { name ->
            val r = svc.openApp(name)
            if (r.startsWith("Opened")) return "Ho gaya, $name khol diya."
            if (name.contains(" ")) return null
            val ans = ask("'$name' naam ka app nahi mila. Wo kaun sa app hai? App ka naam batayein (ya 'nahi').").trim()
            if (ans.isBlank() || Skills.isNo(ans)) return "Theek hai."
            return if (svc.openApp(ans).startsWith("Opened")) {
                learn.setAlias("app", name, ans)
                "Ho gaya, $ans khol diya. Ab '$name' bolne par bhi yahi kholunga."
            } else "'$ans' naam ka bhi koi app nahi mila."
        }
        return null
    }

    private fun parseJson(s: String): JSONObject? {
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(s.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun isFailure(r: String): Boolean =
        r.startsWith("Error") || r.contains("fail", true) || r.startsWith("No such") || r.contains("nahi mila") ||
            r.contains("nahi khula") || r.contains("Unknown") || r.startsWith("Koi input")

    private fun pretty(a: String, j: JSONObject): String = when (a) {
        "open_app" -> "App kholna: " + j.optString("name")
        "tap" -> "Tap kar raha hoon"
        "long_press" -> "Long press"
        "type" -> "Likh raha hoon"
        "scroll" -> "Scroll"
        "swipe" -> "Swipe"
        "web_search" -> "Search: " + j.optString("query")
        "youtube" -> "YouTube: " + j.optString("query")
        "call" -> "Call: " + j.optString("to")
        "whatsapp" -> "WhatsApp: " + j.optString("to")
        "sms" -> "SMS: " + j.optString("to")
        "email" -> "Mail likh raha hoon"
        "create_file" -> "File bana raha hoon"
        else -> a
    }

    private fun stepsText(steps: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until steps.length()) {
            val s = steps.getJSONObject(i)
            val arg = listOf("name", "label", "query", "text", "to").map { s.optString(it) }.firstOrNull { it.isNotBlank() } ?: ""
            sb.append(s.optString("action")).append(if (arg.isNotBlank()) " '${arg.take(30)}'" else "").append("; ")
        }
        return sb.toString().take(260)
    }

    private suspend fun askBack(svc: AgentService, q: String, ask: suspend (String) -> String): String {
        val pkg = svc.lastPkg
        svc.hud("Aapke jawab ka intezaar…", AgentService.HUD_ASK)
        val ans = ask(q)
        if (pkg.isNotBlank() && pkg != ctx.packageName) { svc.launchPackage(pkg); delay(1200) }
        return ans
    }

    private suspend fun exec(a: String, j: JSONObject, svc: AgentService, tools: Tools, ask: suspend (String) -> String): String {
        val askB: suspend (String) -> String = { q -> askBack(svc, q, ask) }
        when (a) {
            "open_app" -> return svc.openApp(j.optString("name"))
            "tap" -> {
                val id = j.optInt("id", -1)
                val r = svc.tap(id)
                if (!r.startsWith("CONFIRM:")) return r
                val l = r.removePrefix("CONFIRM:")
                return if (Skills.isYes(askB("'$l' dabaun? (haan/nahi)"))) svc.tap(id, true) else "User ne mana kiya"
            }
            "long_press" -> return svc.longPress(j.optInt("id", -1))
            "type" -> return svc.type(j.optInt("id", -1), j.optString("text"), j.optBoolean("submit", false))
            "scroll" -> return svc.scroll(j.optString("dir", "down"))
            "swipe" -> return svc.swipe(j.optString("dir", "left"))
            "back" -> return svc.back()
            "home" -> return svc.home()
            "recents" -> return svc.recents()
            "notifications" -> return svc.notifications()
            "screenshot" -> return svc.screenshot()
            "wait" -> { delay((j.optDouble("seconds", 2.0) * 1000).toLong().coerceIn(500, 8000)); return "Waited" }
            "web_search" -> return if (tools.webSearch(j.optString("query"))) "Searching '${j.optString("query")}'" else "Browser nahi khula"
            "youtube" -> return if (tools.youtube(j.optString("query"))) "YouTube khula" else "YouTube nahi khula"
            "maps" -> return if (tools.maps(j.optString("query"))) "Maps khula" else "Maps nahi khula"
            "call" -> {
                val c = resolveContact(j.optString("to"), askB, tools) ?: return "Contact '${j.optString("to")}' nahi mila (ya permission nahi hai)"
                return if (Skills.isYes(askB("${c.name} (${c.number}) ko call karun? (haan/nahi)"))) tools.call(c.number) else "User ne mana kiya"
            }
            "sms" -> {
                val c = resolveContact(j.optString("to"), askB, tools) ?: return "Contact '${j.optString("to")}' nahi mila (ya permission nahi hai)"
                return tools.sms(c.number, j.optString("text"))
            }
            "whatsapp" -> {
                val c = resolveContact(j.optString("to"), askB, tools) ?: return "Contact '${j.optString("to")}' nahi mila (ya permission nahi hai)"
                return tools.whatsapp(c.number, j.optString("text"))
            }
            "email" -> return tools.email(j.optString("to"), j.optString("subject"), j.optString("body"))
            "alarm" -> return tools.alarm(j.optInt("hour", 7), j.optInt("minute", 0), j.optString("label", "Aiva"))
            "timer" -> return tools.timer(j.optInt("seconds", 60))
            "flashlight" -> return tools.flashlight(j.optBoolean("on", true))
            "volume" -> return tools.volume(j.optString("mode", "up"))
            "create_file" -> return tools.createFile(j.optString("name", "aiva_note.txt"), j.optString("content"))
            "ask_user" -> return "User ne kaha: " + askB(j.optString("question"))
            else -> return "Unknown action '$a'"
        }
    }

    /** Seekha hua tareeka dobara chalana. null = kaam nahi bana, naye sire se brain se karo. */
    private suspend fun replay(m: JSONObject, svc: AgentService, tools: Tools, ask: suspend (String) -> String): String? {
        val steps = m.getJSONArray("steps")
        for (i in 0 until steps.length()) {
            if (stop || svc.stopRequested) return "Roka gaya."
            val s = JSONObject(steps.getJSONObject(i).toString())
            val a = s.optString("action")
            svc.hud("Seekha hua tareeka · step ${i + 1}/${steps.length()}")
            if (a == "tap" || a == "long_press") {
                withContext(Dispatchers.Default) { svc.readScreen() }
                val idx = svc.indexOfLabel(s.optString("label"))
                if (idx < 0) return null
                s.put("id", idx)
            } else if (a == "type") {
                withContext(Dispatchers.Default) { svc.readScreen() }
                s.put("id", -1)
            }
            val result = try { exec(a, s, svc, tools, ask) } catch (e: CancellationException) { throw e } catch (e: Throwable) { "Error: ${e.message}" }
            log("↻ $a → $result")
            if (result.startsWith("User ne mana")) return "Theek hai, nahi kiya."
            if (isFailure(result)) return null
            delay(if (a in slowActions) 1800L else 1100L)
        }
        return m.optString("summary").ifBlank { "Ho gaya (seekhe hue tareeke se)." }
    }

    suspend fun run(goal: String, ask: suspend (String) -> String): String {
        val svc = AgentService.instance ?: return "Pehle Accessibility me Aiva ko ON karein."
        val b = brain()
        b.ready()?.let { return it }
        val cloud = b is CloudBrain
        val maxSteps = if (cloud) 25 else 8
        val system = Prompts.agentSystem(cloud, memory.summary())
        val tools = Tools(svc)
        stop = false
        svc.stopRequested = false
        svc.hud("Aiva shuru ho raha hai…")
        svc.home()
        delay(900)

        // 1) Pehle se seekha hua tareeka
        val macro = learn.findMacro(goal)
        if (macro != null) {
            val r = replay(macro, svc, tools, ask)
            if (r != null) { learn.markUse(goal); return r }
            log("Seekha hua tareeka ab kaam nahi kar raha, naye sire se koshish…")
            svc.home(); delay(700)
        }
        // 2) Milte-julte solved kaam misaal ki tarah
        val exText = learn.similarMacros(goal, 1).joinToString("\n") { m ->
            "EXAMPLE (similar task already solved): ${m.optString("goal")} => ${stepsText(m.getJSONArray("steps"))}"
        }

        val history = mutableListOf<String>()
        val recorded = JSONArray()
        var tainted = false
        var lastSig = ""
        var repeats = 0
        for (step in 1..maxSteps) {
            if (stop || svc.stopRequested) return "Roka gaya."
            val screen = withContext(Dispatchers.Default) { svc.readScreen() }.take(if (cloud) 2500 else 1000)
            val user = "GOAL: $goal\n" + (if (exText.isNotBlank()) exText + "\n" else "") +
                "STEPS SO FAR: " + history.takeLast(if (cloud) 10 else 3).joinToString(" | ").ifBlank { "none" } +
                "\nCURRENT SCREEN:\n$screen"
            val reply = withContext(Dispatchers.Default) {
                try { b.decide(system, user) } catch (e: Throwable) { "ERROR " + (e.message ?: e.javaClass.simpleName) }
            }
            if (stop || svc.stopRequested) return "Roka gaya."
            if (reply.isBlank()) return "Mujhe jawab nahi mila, dobara try karein."
            if (reply.startsWith("ERROR")) return "Brain me dikkat: " + reply.removePrefix("ERROR ").take(180)

            val json = parseJson(reply)
            if (json == null) {
                history.add("invalid reply"); log("Step $step: jawab samajh nahi aaya")
                if (!cloud && step >= 3) return "Offline model ye kaam samajh nahi paaya. ⚙ me Online brain try karein."
                continue
            }
            val action = json.optString("action")
            val sig = json.toString() + screen.hashCode()
            if (sig == lastSig) {
                repeats++
                if (repeats >= (if (cloud) 2 else 1)) return "Ek hi step baar baar ho raha tha, isliye ruk gaya."
                history.add("that did not change anything; try a different approach")
                continue
            }
            repeats = 0
            lastSig = sig

            if (action == "done") {
                val summary = json.optString("summary").ifBlank { "Ho gaya." }
                if (!tainted && recorded.length() in 1..15) {
                    learn.saveMacro(goal, recorded, summary)
                    log("📚 Ye tareeka yaad kar liya, agli baar turant hoga.")
                }
                return summary
            }

            val lab = if (action == "tap" || action == "long_press") svc.labelOf(json.optInt("id", -1)) else ""
            svc.hud("Step $step/$maxSteps · ${pretty(action, json)}")
            val result = try {
                exec(action, json, svc, tools, ask)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                "Error: ${e.message}"
            }
            log("Step $step: $action → $result")
            history.add("$action -> $result")

            if (action == "ask_user") {
                tainted = true
            } else if (!isFailure(result) && !result.startsWith("User ne mana")) {
                val rec = JSONObject(json.toString())
                if (action == "tap" || action == "long_press") {
                    if (lab.isBlank()) tainted = true else { rec.remove("id"); rec.put("label", lab) }
                }
                if (action == "type") rec.remove("id")
                recorded.put(rec)
            }
            delay(if (action in slowActions) 1800L else 1100L)
        }
        return "Step limit poori hui, shayad kaam adhura reh gaya."
    }
}
