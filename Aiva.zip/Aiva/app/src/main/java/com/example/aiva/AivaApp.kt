package com.example.aiva

import android.app.Application
import java.io.File

/** Crash hone par wajah file me likh deta hai, taaki agli baar app dikha sake. */
class AivaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText(e.stackTraceToString().take(1500)) } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
