package com.example.aiva

import android.content.SharedPreferences

/** Aiva ki yaaddasht: aapka naam aur "yaad rakho ..." wali baatein. */
class Memory(private val prefs: SharedPreferences) {
    fun name(): String = prefs.getString("mem_name", "") ?: ""
    private fun setName(n: String) { prefs.edit().putString("mem_name", n).apply() }
    fun notes(): List<String> = (prefs.getString("mem_notes", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun add(note: String) {
        val l = notes().toMutableList()
        l.add(note.trim().take(120))
        while (l.size > 10) l.removeAt(0)
        prefs.edit().putString("mem_notes", l.joinToString("\n")).apply()
    }
    fun clear() { prefs.edit().remove("mem_name").remove("mem_notes").apply() }

    fun summary(): String {
        val sb = StringBuilder()
        if (name().isNotBlank()) sb.append("The user's name is ${name()}. ")
        if (notes().isNotEmpty()) sb.append("Remember: ").append(notes().joinToString("; "))
        return sb.toString().take(300)
    }

    /** Agar message yaaddasht se juda hai to seedha jawab (bina AI ke). */
    fun learn(t: String): String? {
        val o = RegexOption.IGNORE_CASE
        if (Regex("(mera\\s+na+m\\s+(kya|btao|batao|bata|bolo))|(what('s| is) my name)", o).containsMatchIn(t))
            return if (name().isNotBlank()) "Aapka naam ${name()} hai." else "Abhi mujhe aapka naam nahi pata. Bataiye, aapka naam kya hai?"
        Regex("^(?:yaad rakho|yaad rakh|remember|याद रखो)\\s+(?:ki\\s+|that\\s+)?(.+)$", o).find(t)?.let {
            add(it.groupValues[1]); return "Theek hai, yaad rakh liya."
        }
        Regex("(?:mera\\s+na+m|my\\s+name\\s+is|मेरा\\s+नाम)\\s+([\\p{L}]{2,20})", o).find(t)?.let {
            val n = it.groupValues[1].replaceFirstChar { c -> c.uppercase() }
            if (n.lowercase() !in setOf("kya", "hai", "btao", "batao", "bata", "bolo", "mera")) {
                setName(n); return "Achha, $n ji! Ab main aapka naam yaad rakhunga."
            }
        }
        if (Regex("^(kya yaad hai|what do you remember|meri yaaddasht)", o).containsMatchIn(t.trim()))
            return if (notes().isEmpty() && name().isBlank()) "Abhi mujhe kuch yaad nahi hai." else
                "Mujhe yaad hai: " + (if (name().isNotBlank()) "aapka naam ${name()}. " else "") + notes().joinToString(". ")
        if (Regex("^(bhool jao|forget everything|yaaddasht saaf)", o).containsMatchIn(t.trim())) { clear(); return "Sab kuch bhula diya." }
        return null
    }
}
