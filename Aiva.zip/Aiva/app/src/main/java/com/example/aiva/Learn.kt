package com.example.aiva

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Aiva ka "seekhna": nicknames, pasand aaye jawab, kaam ke macros aur aapki aadatein.
 * Sab kuch sirf aapke phone me save hota hai.
 */
class Learn(private val prefs: SharedPreferences) {
    private val stop = setOf("mere", "mera", "meri", "ka", "ki", "ke", "ko", "me", "mein", "par", "pe", "ek",
        "please", "plz", "kar", "karo", "do", "de", "the", "a", "my", "to", "and", "aur")

    private fun toks(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 && it !in stop }.toSet()

    private fun jac(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val i = a.intersect(b).size.toDouble()
        return i / (a.size + b.size - i)
    }

    private fun arr(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (e: Exception) { JSONArray() }
    private fun obj(key: String): JSONObject = try { JSONObject(prefs.getString(key, "{}")) } catch (e: Exception) { JSONObject() }

    // ---------- 1) Nicknames ----------
    fun alias(kind: String, name: String): String? {
        val k = "$kind:${name.lowercase().trim()}"
        val o = obj("aliases")
        return if (o.has(k)) o.getString(k) else null
    }
    fun setAlias(kind: String, name: String, value: String) {
        val o = obj("aliases")
        o.put("$kind:${name.lowercase().trim()}", value.trim())
        prefs.edit().putString("aliases", o.toString()).apply()
    }
    fun aliasList(): List<String> {
        val o = obj("aliases")
        return o.keys().asSequence().map { it.replace(":", " ") + " → " + o.getString(it) }.toList()
    }

    // ---------- 2) Pasand aaye / sudhare hue jawab ----------
    fun addChat(q: String, a: String, src: String) {
        val l = arr("chat_ex")
        val out = JSONArray()
        for (i in 0 until l.length()) {
            val o = l.getJSONObject(i)
            if (o.getString("q").lowercase() != q.lowercase()) out.put(o)
        }
        out.put(JSONObject().put("q", q.take(200)).put("a", a.take(500)).put("src", src).put("t", System.currentTimeMillis()))
        val capped = JSONArray()
        for (i in maxOf(0, out.length() - 40) until out.length()) capped.put(out.get(i))
        prefs.edit().putString("chat_ex", capped.toString()).apply()
    }

    /** Sawal se milte-julte sikhaye hue jawab (offline model ko misaal ki tarah milte hain). */
    fun bestChat(q: String, k: Int): List<Pair<String, String>> {
        val l = arr("chat_ex")
        if (l.length() == 0) return emptyList()
        val qt = toks(q)
        return (0 until l.length()).map { l.getJSONObject(it) }
            .map { it to (jac(qt, toks(it.getString("q"))) + if (it.optString("src") == "user") 0.15 else 0.0) }
            .filter { it.second > 0.15 }
            .sortedByDescending { it.second }
            .take(k)
            .map { it.first.getString("q") to it.first.getString("a") }
    }

    // ---------- 3) Macros (kaam ke seekhe hue tareeke) ----------
    fun saveMacro(goal: String, steps: JSONArray, summary: String) {
        val l = arr("macros")
        val norm = toks(goal).sorted().joinToString(" ")
        var uses = 0
        val out = JSONArray()
        for (i in 0 until l.length()) {
            val o = l.getJSONObject(i)
            if (o.getString("norm") == norm) uses = o.optInt("uses") else out.put(o)
        }
        out.put(JSONObject().put("goal", goal.take(160)).put("norm", norm).put("steps", steps)
            .put("summary", summary.take(120)).put("uses", uses).put("t", System.currentTimeMillis()))
        val capped = JSONArray()
        for (i in maxOf(0, out.length() - 30) until out.length()) capped.put(out.get(i))
        prefs.edit().putString("macros", capped.toString()).apply()
    }

    fun findMacro(goal: String): JSONObject? {
        val l = arr("macros")
        val g = toks(goal)
        if (g.isEmpty()) return null
        var best: JSONObject? = null
        var bs = 0.0
        for (i in 0 until l.length()) {
            val o = l.getJSONObject(i)
            val s = jac(g, toks(o.getString("goal")))
            if (s > bs) { bs = s; best = o }
        }
        return if (bs >= 0.9) best else null
    }

    fun similarMacros(goal: String, k: Int): List<JSONObject> {
        val l = arr("macros")
        val g = toks(goal)
        return (0 until l.length()).map { l.getJSONObject(it) }
            .map { it to jac(g, toks(it.getString("goal"))) }
            .filter { it.second >= 0.25 && it.second < 0.9 }
            .sortedByDescending { it.second }.take(k).map { it.first }
    }

    fun markUse(goal: String) {
        val l = arr("macros")
        val norm = toks(goal).sorted().joinToString(" ")
        for (i in 0 until l.length()) {
            val o = l.getJSONObject(i)
            if (o.getString("norm") == norm) o.put("uses", o.optInt("uses") + 1)
        }
        prefs.edit().putString("macros", l.toString()).apply()
    }

    fun deleteMacro(goal: String) {
        val l = arr("macros")
        val norm = toks(goal).sorted().joinToString(" ")
        val out = JSONArray()
        for (i in 0 until l.length()) {
            val o = l.getJSONObject(i)
            if (o.getString("norm") != norm) out.put(o)
        }
        prefs.edit().putString("macros", out.toString()).apply()
    }

    fun macroGoals(): List<String> {
        val l = arr("macros")
        return (0 until l.length()).map { l.getJSONObject(it).getString("goal") + "  (" + l.getJSONObject(it).optInt("uses") + "x)" }
    }

    // ---------- 4) Aadatein ----------
    fun use(cmd: String) {
        val c = cmd.lowercase().trim().take(40)
        if (c.length < 3) return
        val o = obj("usage")
        o.put(c, o.optInt(c) + 1)
        prefs.edit().putString("usage", o.toString()).apply()
    }

    fun top(n: Int): List<String> {
        val o = obj("usage")
        return o.keys().asSequence().map { it to o.getInt(it) }.filter { it.second >= 2 }
            .sortedByDescending { it.second }.take(n).map { it.first }.toList()
    }

    // ---------- Summary / saaf / export ----------
    fun counts(): String =
        "Nicknames: ${obj("aliases").length()}\nSikhaye hue jawab: ${arr("chat_ex").length()}\nSeekhe hue tareeke: ${arr("macros").length()}\nYaad ki hui aadatein: ${obj("usage").length()}"

    fun clearAll() {
        prefs.edit().remove("aliases").remove("chat_ex").remove("macros").remove("usage").apply()
    }

    fun exportJsonl(ctx: Context): String {
        val sb = StringBuilder()
        fun line(u: String, a: String) {
            sb.append(JSONObject().put("messages", JSONArray()
                .put(JSONObject().put("role", "user").put("content", u))
                .put(JSONObject().put("role", "assistant").put("content", a))).toString()).append("\n")
        }
        val ex = arr("chat_ex")
        for (i in 0 until ex.length()) { val o = ex.getJSONObject(i); line(o.getString("q"), o.getString("a")) }
        val ms = arr("macros")
        for (i in 0 until ms.length()) { val o = ms.getJSONObject(i); line("PHONE TASK: " + o.getString("goal"), o.getJSONArray("steps").toString()) }
        if (sb.isEmpty()) return "Abhi export karne layak kuch seekha nahi hai."
        return Files.saveText(ctx, "aiva_training_data.jsonl", sb.toString())
    }
}
