package com.example.aiva

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore

class Contact(val name: String, val number: String)

/** App-ke-naam ke Hindi/Hinglish nicknames. */
object Aliases {
    private val map = mapOf(
        "mail" to listOf("gmail", "mail", "email"), "email" to listOf("gmail", "mail", "email"),
        "gmail" to listOf("gmail"), "जीमेल" to listOf("gmail"), "मेल" to listOf("gmail", "mail"),
        "photo" to listOf("photos", "gallery"), "photos" to listOf("photos", "gallery"),
        "gallery" to listOf("gallery", "photos"), "pics" to listOf("photos", "gallery"),
        "फोटो" to listOf("photos", "gallery"), "गैलरी" to listOf("gallery", "photos"),
        "contacts" to listOf("contacts"), "contact" to listOf("contacts"), "content" to listOf("contacts", "files"),
        "message" to listOf("messages", "messaging", "sms"), "messages" to listOf("messages", "messaging", "sms"),
        "sms" to listOf("messages", "messaging"), "camera" to listOf("camera"), "कैमरा" to listOf("camera"),
        "calculator" to listOf("calculator"), "कैलकुलेटर" to listOf("calculator"),
        "clock" to listOf("clock"), "alarm" to listOf("clock"), "घड़ी" to listOf("clock"),
        "files" to listOf("files", "file manager", "my files"), "file" to listOf("files", "file manager", "my files"),
        "music" to listOf("music", "spotify", "youtube music"), "browser" to listOf("chrome", "browser"),
        "chrome" to listOf("chrome"), "क्रोम" to listOf("chrome"),
        "settings" to listOf("settings"), "setting" to listOf("settings"), "सेटिंग" to listOf("settings"),
        "सेटिंग्स" to listOf("settings"), "phone" to listOf("phone", "dialer"), "dialer" to listOf("phone", "dialer"),
        "फोन" to listOf("phone", "dialer"), "maps" to listOf("maps"), "map" to listOf("maps"), "मैप्स" to listOf("maps"),
        "playstore" to listOf("play store"), "play store" to listOf("play store"),
        "whatsapp" to listOf("whatsapp"), "व्हाट्सएप" to listOf("whatsapp"),
        "youtube" to listOf("youtube"), "यूट्यूब" to listOf("youtube")
    )
    /** Seekhe hue nicknames (Learn se judta hai). */
    var learned: ((String) -> String?)? = null

    fun candidates(name: String): List<String> {
        val k = name.lowercase().trim()
        val l = learned?.invoke(k)
        return (if (l != null) listOf(l) else emptyList()) + (map[k] ?: emptyList()) + k
    }
}

/** Seedhe (intent-based) kaam: Accessibility se zyada bharosemand. */
class Tools(private val svc: AgentService) {
    private fun start(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); svc.startActivity(i); true
    } catch (e: Exception) { false }

    fun webSearch(q: String) = start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
    fun youtube(q: String) = start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
    fun maps(q: String) = start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))

    fun hasContactsPerm() = svc.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun lookup(nameOrNumber: String): Contact? {
        val digits = nameOrNumber.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 5 && nameOrNumber.none { it.isLetter() }) return Contact(nameOrNumber.trim(), digits)
        if (!hasContactsPerm()) return null
        val c = svc.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + nameOrNumber.trim() + "%"), null) ?: return null
        c.use { if (it.moveToFirst()) return Contact(it.getString(0), it.getString(1)) }
        return null
    }

    private fun waNumber(n: String): String {
        var d = n.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2) else if (d.length == 11 && d.startsWith("0")) d = d.substring(1)
        if (d.length == 10) d = "91$d"
        return d
    }

    fun call(number: String): String {
        val clean = number.filter { it.isDigit() || it == '+' }
        val granted = svc.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val ok = start(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$clean")))
        return if (!ok) "Call nahi lag paaya" else if (granted) "Call laga diya" else "Dialer khol diya (seedha call ke liye Call permission dein)"
    }

    fun sms(number: String, text: String): String {
        val clean = number.filter { it.isDigit() || it == '+' }
        val ok = start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$clean")).putExtra("sms_body", text))
        return if (ok) "SMS draft khul gaya, ab Send dabana hai" else "SMS app nahi khula"
    }

    fun whatsapp(number: String, text: String): String {
        val u = Uri.parse("https://wa.me/" + waNumber(number) + "?text=" + Uri.encode(text))
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            if (start(Intent(Intent.ACTION_VIEW, u).setPackage(pkg))) return "WhatsApp chat khul gaya, ab Send dabana hai"
        }
        return if (start(Intent(Intent.ACTION_VIEW, u))) "WhatsApp link khola" else "WhatsApp nahi khula"
    }

    fun email(to: String, subject: String, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            .putExtra(Intent.EXTRA_SUBJECT, subject)
            .putExtra(Intent.EXTRA_TEXT, body)
        return if (start(i)) "Mail draft khul gaya, ab Send dabana hai" else "Mail app nahi khula"
    }

    fun alarm(h: Int, m: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(i)) "Alarm set ho gaya: %02d:%02d".format(h, m) else "Alarm set nahi ho paaya"
    }

    fun timer(seconds: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(i)) "Timer lag gaya: $seconds second" else "Timer set nahi ho paaya"
    }

    fun flashlight(on: Boolean): String = try {
        val cm = svc.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) "Is phone me flashlight nahi mili" else { cm.setTorchMode(id, on); if (on) "Torch ON kar di." else "Torch band kar di." }
    } catch (e: Exception) { "Torch me dikkat: ${e.message}" }

    fun volume(mode: String): String {
        val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (mode) {
            "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            else -> return "Unknown volume mode"
        }
        return "Volume $mode kar diya."
    }

    fun createFile(name: String, content: String): String = Files.saveText(svc, name, content)
}
