package com.example.aiva

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Aiva ki aawaz (TTS) aur kaan. Sunne ke 3 tareeke try hota hai:
 * 0 = Google recognizer (seedha), 1 = phone ka default recognizer, 2 = Google voice popup.
 */
class Voice(private val act: Activity) {
    var onHeard: (String) -> Unit = {}
    var onListening: (Boolean) -> Unit = {}
    var onNote: (String) -> Unit = {}
    var onStopped: () -> Unit = {}
    var onSpeakEnd: () -> Unit = {}
    var lang = "hi-IN"
    @Volatile var continuous = false
    @Volatile var speaking = false

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    var ttsReady = false
        private set
    private var rec: SpeechRecognizer? = null
    private var errors = 0
    private var strategy = 0

    fun init() {
        tts = TextToSpeech(act) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (!ttsReady) {
                onNote("⚠️ Phone me Text-to-Speech engine nahi mila, isliye Aiva bol nahi paayega. Settings → Language → Text-to-speech me 'Speech Services by Google' chunein (⚙ → TTS settings).")
            } else {
                tts?.setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { ended() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { ended() } }
                })
            }
        }
    }

    private fun ended() {
        speaking = false
        onSpeakEnd()
        if (continuous) main.postDelayed({ if (continuous) startListening() }, 450)
    }

    fun speak(text: String) {
        val t = tts
        if (t == null || !ttsReady) { main.post { ended() }; return }
        stopListening()
        val dev = text.any { it in '\u0900'..'\u097F' }
        val r = t.setLanguage(if (dev) Locale("hi", "IN") else Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
        speaking = true
        val res = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aiva")
        if (res != TextToSpeech.SUCCESS) {
            speaking = false
            onNote("⚠️ Awaaz nahi nikli. Media volume check karein ya TTS settings kholein (⚙).")
            main.post { ended() }
        }
    }

    fun stopSpeaking() { tts?.stop(); speaking = false }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rms: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onResults(b: Bundle?) {
            val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            onListening(false)
            if (text.isEmpty()) { retry(); return }
            errors = 0
            onHeard(text)
        }
        override fun onError(code: Int) {
            onListening(false)
            when (code) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retry()
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { continuous = false; onNote("Mic ki permission chahiye."); onStopped() }
                else -> {
                    errors++
                    if (errors >= 2) {
                        errors = 0
                        if (strategy < 2) {
                            strategy++
                            onNote("Voice ka tareeka badla (error $code) — dobara koshish…")
                            retry(600)
                        } else {
                            continuous = false
                            onNote("Voice sunna nahi chal raha (error $code). Google app / Speech Services update karein.")
                            onStopped()
                        }
                    } else retry(1000)
                }
            }
        }
    }

    private fun retry(delay: Long = 500) {
        if (!continuous) return
        main.postDelayed({ if (continuous && !speaking) startListening() }, delay)
    }

    private fun googleInstalled(): Boolean = try {
        act.packageManager.getPackageInfo("com.google.android.googlequicksearchbox", 0); true
    } catch (e: Exception) { false }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)

    fun startListening() {
        if (speaking) return
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        main.post {
            try {
                if (strategy >= 2) {
                    onListening(true)
                    act.startActivityForResult(recognizerIntent(), 3)
                    return@post
                }
                if (!SpeechRecognizer.isRecognitionAvailable(act)) { strategy = 2; startListening(); return@post }
                rec?.destroy()
                val r = if (strategy == 0 && googleInstalled())
                    SpeechRecognizer.createSpeechRecognizer(act,
                        ComponentName("com.google.android.googlequicksearchbox",
                            "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"))
                else SpeechRecognizer.createSpeechRecognizer(act)
                r.setRecognitionListener(listener)
                rec = r
                r.startListening(recognizerIntent())
                onListening(true)
            } catch (e: Exception) {
                strategy++
                onNote("Mic start nahi hua (${e.message}). Dusra tareeka try kar raha hoon.")
                if (strategy <= 2) retry(500) else { continuous = false; onStopped() }
            }
        }
    }

    /** Popup wale tareeke ka jawab. */
    fun onDialogResult(res: Int, data: Intent?) {
        onListening(false)
        if (res == Activity.RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) { errors = 0; onHeard(t); return }
        }
        continuous = false
        onStopped()
    }

    fun stopListening() {
        main.post {
            try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
            rec = null
        }
    }

    fun shutdown() {
        continuous = false
        try { rec?.destroy() } catch (_: Exception) {}
        tts?.stop(); tts?.shutdown()
    }
}
