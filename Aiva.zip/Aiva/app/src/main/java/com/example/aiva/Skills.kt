package com.example.aiva

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Turant jawab (bina AI ke): samay, tarikh, battery, parichay, chutkule, greeting. */
object Skills {
    private val jokes = listOf(
        "Teacher ne pucha, homework kahan hai? Bachha bola, sir, wo cloud me tha aur network chala gaya.",
        "Doctor ne kaha, mobile kam use karo. Mareez bola, theek hai, ye salah WhatsApp par bhej dijiye.",
        "Pappu ne WiFi ka password poocha. Dukaan wala bola, pehle chai pi lo. Pappu bola, chai ka password kya hai?",
        "Bank wale ne kaha, aapka balance zero hai. Main bola, wah, kam se kam consistent to hai.",
        "Alarm ne subah 6 baje kaha, uth jao. Maine kaha, tum kaun ho? Alarm bola, tumhara purana dost, snooze."
    )
    private var jokeIdx = 0

    fun isYes(s: String): Boolean =
        Regex("^(haan|han|ha|yes|yeah|yep|ok|okay|theek|thik|kar do|karo|bilkul|sure|हाँ|हां|ठीक|हा)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s.trim())

    fun isNo(s: String): Boolean =
        Regex("^(nahi|nahin|no|nope|cancel|rehne do|mat karo|ruko|नहीं|नही|मत)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s.trim())

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    private fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "Battery ki jaankari nahi mili."
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0) level * 100 / scale else -1
        return "Battery ${pct} percent hai" + if (charging) " aur charge ho rahi hai." else "."
    }

    fun answer(ctx: Context, t: String, memory: Memory, localChat: Boolean): String? {
        memory.learn(t)?.let { return it }
        val nm = memory.name().let { if (it.isBlank()) "" else " $it ji" }
        if (rx("\\b(kitne baje|what time|time kya|samay kya|abhi time|current time)\\b").containsMatchIn(t))
            return "Abhi samay hai " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + "."
        if (rx("(aaj.*(tarikh|date|din)|what('s| is) (the )?date|what day)").containsMatchIn(t))
            return "Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()) + " hai."
        if (rx("\\b(battery|charge kitna|charging)\\b").containsMatchIn(t)) return battery(ctx)
        if (rx("^(tum kaun ho|aap kaun ho|who are you|tumhara naam kya hai|tumhara naam|apna parichay)").containsMatchIn(t.trim()))
            return "Main Aiva hoon, aapka phone assistant. Main baat kar sakta hoon aur aapke phone ko chala sakta hoon."
        if (rx("^(tum kya kar sakte ho|what can you do|aap kya kar sakte ho)").containsMatchIn(t.trim()))
            return "Main baat kar sakta hoon, apps kholna, call, WhatsApp aur mail bhejna, search, alarm, file banana aur phone ke andar kaam karna jaise kaam kar sakta hoon. Bas boliye."
        if (rx("^(thank you|thanks|shukriya|dhanyavad|धन्यवाद|शुक्रिया)").containsMatchIn(t.trim()))
            return "Koi baat nahi$nm! Aur kuch chahiye to bataiye."
        if (localChat) {
            if (rx("^(hi+|hello+|hey+|helo|namaste|namaskar|नमस्ते|हेलो)$").matches(t.trim()))
                return "Namaste$nm! Bataiye, main aapki kya madad karun?"
            if (rx("^(kaise ho|kaisa hai|how are you|kya haal|kya hal)").containsMatchIn(t.trim()))
                return "Main badhiya hoon, shukriya! Aap kaise hain?"
            if (rx("(joke|chutkula|chutkule|चुटकुला|जोक)").containsMatchIn(t)) {
                val j = jokes[jokeIdx % jokes.size]; jokeIdx++; return j
            }
        }
        return null
    }
}
