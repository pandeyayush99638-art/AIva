package com.example.aiva

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*
import kotlinx.coroutines.*
import java.io.File

class MainActivity : Activity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var llm: LlmEngine
    private lateinit var localBrain: LocalBrain
    private lateinit var cloudBrain: CloudBrain
    private lateinit var memory: Memory
    private lateinit var learn: Learn
    private lateinit var agent: Agent
    private lateinit var voice: Voice
    private lateinit var prefs: android.content.SharedPreferences

    private lateinit var aurora: AuroraView
    private lateinit var orb: OrbView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var actionBtn: TextView
    private lateinit var stopBar: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var accRow: TextView
    private lateinit var modelRow: TextView
    private lateinit var orbLabel: TextView
    private lateinit var brainBadge: TextView
    private lateinit var speakBtn: TextView
    private lateinit var langBtn: TextView
    private lateinit var quickRow: LinearLayout
    private val modeChips = mutableListOf<TextView>()

    private val turns = mutableListOf<Pair<Boolean, String>>()
    private var mode = 0            // 0 Auto, 1 Baat, 2 Kaam
    private var speakOn = true
    private var voiceMode = false
    private var busy = false
    @Volatile private var cancelled = false
    private var job: Job? = null
    private var actionPulse: ValueAnimator? = null
    private var pendingAnswer: CompletableDeferred<String>? = null
    private var pendingCorrection: Triple<String, String, String>? = null

    private val taskRe = Regex(
        "\\b(open|launch|call|dial|turn on|turn off|enable|disable|volume|brightness|wifi|wi-fi|bluetooth|flashlight|torch|scroll|click|tap|search|install|uninstall|screenshot|alarm|timer|whatsapp|send|write|create|play|download|mail|email|message|sms|photo|gallery|camera|youtube|maps|chrome|file)\\b" +
        "|kholo|khol |chalu|chalao|band karo|on karo|off karo|bhejo|bhej do|dhundo|khojo|likho|likh do|banao|bana do|lagao|laga do|खोलो|चालू|बंद|भेजो|कॉल|खोजो|ढूंढो|लिखो|बनाओ",
        RegexOption.IGNORE_CASE)
    private val stopWords = Regex("^(stop|ruko|ruk jao|bas|chup|रुको|बंद करो|बस|चुप)$", RegexOption.IGNORE_CASE)
    private val failRe = Regex("^(Roka|Brain me|Offline model|Ek hi step|Step limit|Mujhe jawab|Pehle|Contact|Maaf)")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: String, r: Int, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
        setColor(Color.parseColor(color))
    }
    private fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(7), dp(12), dp(7)); background = bg("#26265A", 16)
        setOnClickListener { onClick() }
        pressAnim()
    }
    private fun iconBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setOnClickListener { onClick() }
        pressAnim()
    }

    private fun isLocal() = prefs.getString("brain", "local") != "cloud"
    private fun brain(): Brain = if (isLocal()) localBrain else cloudBrain

    private fun popIn(v: View, fromRight: Boolean) {
        v.alpha = 0f
        v.translationY = dp(18).toFloat()
        v.translationX = if (fromRight) dp(40).toFloat() else -dp(20).toFloat()
        v.scaleX = 0.96f; v.scaleY = 0.96f
        v.animate().alpha(1f).translationY(0f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        volumeControlStream = AudioManager.STREAM_MUSIC
        prefs = getSharedPreferences("aiva", MODE_PRIVATE)
        llm = LlmEngine(this)
        localBrain = LocalBrain(llm)
        cloudBrain = CloudBrain(prefs)
        memory = Memory(prefs)
        learn = Learn(prefs)
        Aliases.learned = { k -> learn.alias("app", k) }
        agent = Agent(this, { brain() }, memory, learn) { msg -> runOnUiThread { note("• $msg") } }
        voice = Voice(this)
        voice.onHeard = { t -> onHeard(t) }
        voice.onListening = { on -> if (on) setOrb(1, "Sun raha hoon…") }
        voice.onNote = { m -> note(m) }
        voice.onStopped = { voiceMode = false; updateAction(); setOrb(0, "Taiyaar hoon") }
        voice.onSpeakEnd = { if (!voiceMode) setOrb(0, "Taiyaar hoon") }
        voice.init()

        window.statusBarColor = Color.parseColor("#0A0A1C")
        aurora = AuroraView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(30), dp(14), dp(10))
        }

        // ---- Header
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "Aiva"; textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
        }
        title.paint.shader = LinearGradient(0f, 0f, dp(90).toFloat(), 0f,
            intArrayOf(Color.parseColor("#C3B1FF"), Color.parseColor("#5BC8FF")), null, Shader.TileMode.CLAMP)
        brainBadge = TextView(this).apply {
            textSize = 11f; setTextColor(Color.parseColor("#D6D3FF"))
            setPadding(dp(10), dp(3), dp(10), dp(3)); background = bg("#2A2A66", 12)
            setOnClickListener { openSettings() }
            pressAnim()
        }
        titleBox.addView(title)
        titleBox.addView(brainBadge, LinearLayout.LayoutParams(-2, -2))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        speakBtn = iconBtn("🔊") { toggleSpeak() }
        langBtn = iconBtn("हिं") { toggleLang() }
        val gear = iconBtn("⚙") { openSettings() }
        val trash = iconBtn("🗑") { chat.removeAllViews(); turns.clear() }
        listOf(speakBtn, langBtn, gear, trash).forEach { header.addView(it, LinearLayout.LayoutParams(dp(42), dp(40))) }
        root.addView(header)

        // ---- Orb
        orb = OrbView(this)
        root.addView(orb, LinearLayout.LayoutParams(dp(120), dp(120)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(2)
        })
        orbLabel = TextView(this).apply {
            text = "Taiyaar hoon"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B9B6E8"))
        }
        root.addView(orbLabel, LinearLayout.LayoutParams(-1, -2))

        // ---- Mode chips
        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("✨ Auto", "💬 Baat", "🤖 Kaam").forEachIndexed { i, s ->
            val c = chip(s) { mode = i; refreshModes() }
            modeChips.add(c)
            modes.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        root.addView(modes, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        // ---- Setup card
        setupCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg("#1E1E42", 14)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        accRow = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        modelRow = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { openSettings() }
        }
        setupCard.addView(accRow); setupCard.addView(modelRow)
        root.addView(setupCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // ---- Chat
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(chat); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        // ---- Stop bar
        stopBar = TextView(this).apply {
            text = "⏹  Roko"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(18), dp(8), dp(18), dp(8)); background = bg("#E5484D", 18)
            visibility = View.GONE
            setOnClickListener { stopAll() }
            pressAnim()
        }
        root.addView(stopBar, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(6)
        })

        // ---- Quick chips (aapki aadat ke hisaab se badalte hain)
        quickRow = LinearLayout(this)
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(quickRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        // ---- Input bar
        input = EditText(this).apply {
            hint = "Aiva se kuch bhi kahein…"; textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8E8CB0"))
            background = bg("#1E1E42", 24); setPadding(dp(18), dp(10), dp(18), dp(10)); maxLines = 4
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { updateAction() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        actionBtn = TextView(this).apply {
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = bg("#7C5CFF", 24)
            setOnClickListener {
                val t = input.text.toString()
                if (t.isNotBlank()) { input.setText(""); send(t) } else toggleVoice()
            }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(actionBtn, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val frame = FrameLayout(this)
        frame.addView(aurora, FrameLayout.LayoutParams(-1, -1))
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        refreshModes(); updateAction(); setOrb(0, "Taiyaar hoon"); refreshQuick()
        aivaBubble("Namaste! Main Aiva hoon. Mujhse baat karein, ya 🎤 dabakar bolte rahein. “WhatsApp kholo”, “Ayush ko call karo”, “alarm 7 baje lagao” jaise kaam bhi bata sakte hain. Main aapse seekhta bhi hoon: jawab pasand aaye to 👍 dabayein.")

        reportLastCrash()
        if (!prefs.getBoolean("permAsked", false)) {
            prefs.edit().putBoolean("permAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 8)
        }
        warmUp()
    }

    // ---------------- Crash / safe mode ----------------
    private fun reportLastCrash() {
        val f = File(filesDir, "crash.txt")
        if (f.exists()) {
            note("⚠️ Pichhli baar app crash hua. Wajah:\n" + f.readText().take(350))
            f.delete()
        }
        val inflight = prefs.getString("inflight", null)
        if (inflight != null) {
            val fails = prefs.getInt("fails", 0) + 1
            prefs.edit().remove("inflight").putInt("fails", fails).commit()
            if (fails >= 2) {
                prefs.edit().putBoolean("safe", true).commit()
                note("⚠️ Model 2 baar crash hua. Safe mode ON (chhote jawab, kam memory). ⚙ → Safe mode reset se wapas normal kar sakte hain.")
            } else {
                note("⚠️ Pichhli baar model chalte waqt app band hua. Agar dobara ho to main safe mode ON kar dunga.")
            }
        }
    }

    // ---------------- Orb / UI state ----------------
    private fun setOrb(state: Int, label: String) {
        orb.setState(state)
        if (orbLabel.text.toString() != label) {
            orbLabel.animate().cancel()
            orbLabel.alpha = 0f
            orbLabel.text = label
            orbLabel.animate().alpha(1f).setDuration(220).start()
        }
    }

    private fun refreshModes() {
        modeChips.forEachIndexed { i, c ->
            (c.background as GradientDrawable).setColor(Color.parseColor(if (i == mode) "#7C5CFF" else "#26265A"))
        }
    }

    private fun refreshQuick() {
        quickRow.removeAllViews()
        val learned = learn.top(4)
        val cmds = (learned + listOf("Settings kholo", "Samay kya hai", "Battery kitni hai", "Ek joke sunao")).distinct().take(6)
        cmds.forEachIndexed { i, s ->
            val c = chip(if (s in learned) "★ $s" else s) { send(s) }
            quickRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
            c.alpha = 0f
            c.animate().alpha(1f).setStartDelay(i * 60L).setDuration(250).start()
        }
    }

    private fun updateAction() {
        if (!::actionBtn.isInitialized || !::input.isInitialized) return
        val hasText = input.text.isNotBlank()
        actionBtn.text = if (hasText) "➤" else if (voiceMode) "⏹" else "🎤"
        (actionBtn.background as GradientDrawable).setColor(Color.parseColor(if (voiceMode) "#E5484D" else "#7C5CFF"))
        actionPulse?.cancel()
        actionBtn.scaleX = 1f; actionBtn.scaleY = 1f
        if (voiceMode && !hasText) {
            actionPulse = ValueAnimator.ofFloat(1f, 1.14f).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { actionBtn.scaleX = it.animatedValue as Float; actionBtn.scaleY = it.animatedValue as Float }
                start()
            }
        }
    }

    private fun setBusy(b: Boolean) {
        busy = b
        if (b) {
            stopBar.alpha = 0f
            stopBar.translationY = dp(14).toFloat()
            stopBar.visibility = View.VISIBLE
            stopBar.animate().alpha(1f).translationY(0f).setDuration(220).start()
        } else {
            stopBar.animate().alpha(0f).setDuration(160).withEndAction { if (!busy) stopBar.visibility = View.GONE }.start()
        }
        if (!b && !voiceMode && !voice.speaking) setOrb(0, "Taiyaar hoon")
    }

    override fun onResume() {
        super.onResume()
        aurora.resumeAnim()
        AgentService.instance?.hideHud()
        refreshStatus()
        refreshQuick()
    }

    override fun onPause() {
        aurora.pauseAnim()
        super.onPause()
    }

    private fun refreshStatus() {
        val acc = AgentService.instance != null
        val ready = brain().ready() == null
        accRow.text = (if (acc) "✅" else "❌") + "  Phone control: Accessibility me Aiva ON karo" + if (acc) "" else "  (tap)"
        modelRow.text = (if (ready) "✅" else "❌") + "  Dimaag: " + (if (isLocal()) "Offline model" else "Online API") +
            if (ready) " taiyaar" else " — setup karein (tap)"
        brainBadge.text = if (isLocal()) "📱 Offline" else "☁️ Online · " + (if (prefs.getString("provider", "gemini") == "claude") "Claude" else "Gemini")
        val show = !(acc && ready)
        if (show && setupCard.visibility != View.VISIBLE) {
            setupCard.alpha = 0f; setupCard.visibility = View.VISIBLE
            setupCard.animate().alpha(1f).setDuration(250).start()
        } else if (!show && setupCard.visibility == View.VISIBLE) {
            setupCard.animate().alpha(0f).setDuration(220).withEndAction { setupCard.visibility = View.GONE; setupCard.alpha = 1f }.start()
        }
    }

    // ---------------- Bubbles ----------------
    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun userBubble(t: String) {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.WHITE); setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#7C5CFF"), Color.parseColor("#5B8CFF"))).apply { cornerRadius = dp(18).toFloat() }
            maxWidth = (resources.displayMetrics.widthPixels * 0.78).toInt()
        }
        chat.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END; topMargin = dp(8) })
        popIn(tv, true)
        scrollDown()
    }

    private fun aivaBubble(t: String, visible: Boolean = true): TextView {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.parseColor("#F1F0FF")); setTextIsSelectable(true)
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = bg("#24244D", 18)
            maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
            if (!visible) visibility = View.GONE
        }
        chat.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; topMargin = dp(8) })
        if (visible) popIn(tv, false)
        scrollDown()
        return tv
    }

    private fun note(t: String) {
        val tv = TextView(this).apply {
            text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.parseColor("#8E8CB0"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        chat.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        tv.alpha = 0f
        tv.animate().alpha(1f).setDuration(250).start()
        scrollDown()
    }

    private fun addYesNo() {
        val row = LinearLayout(this)
        row.addView(chip("✅ Haan") { chat.removeView(row); send("haan") }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        row.addView(chip("❌ Nahi") { chat.removeView(row); send("nahi") })
        chat.addView(row, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; topMargin = dp(6) })
        popIn(row, false)
        scrollDown()
    }

    /** 👍 / 👎: Aiva seekhta hai. kind = "chat" ya "task". */
    private fun addFeedback(q: String, a: String, kind: String, src: String) {
        val row = LinearLayout(this)
        fun small(label: String, color: String) = TextView(this).apply {
            text = label; textSize = 13f; setTextColor(Color.parseColor(color))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        val up = small("👍", "#FFFFFF")
        val down = small("👎", "#FFFFFF")
        up.alpha = 0.8f; down.alpha = 0.8f
        up.setOnClickListener {
            if (kind == "chat") learn.addChat(q, a, src)
            row.removeAllViews()
            row.addView(small("✓ Seekh liya", "#7CF0A8"))
        }
        down.setOnClickListener {
            row.removeAllViews()
            row.addView(small("Theek hai", "#8E8CB0"))
            if (kind == "chat") {
                pendingCorrection = Triple(q, a, src)
                aivaBubble("Maaf karna! Sahi jawab kya hona chahiye? Likh dein ya bol dein, main yaad rakhunga.")
            } else {
                learn.deleteMacro(q)
                note("Is kaam ka seekha hua tareeka hata diya.")
            }
        }
        up.pressAnim(); down.pressAnim()
        row.addView(up); row.addView(down)
        chat.addView(row, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; topMargin = dp(2) })
        row.alpha = 0f
        row.animate().alpha(1f).setStartDelay(400).setDuration(300).start()
        scrollDown()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- Toggles ----------------
    private fun toggleSpeak() {
        speakOn = !speakOn
        speakBtn.text = if (speakOn) "🔊" else "🔇"
        if (!speakOn) voice.stopSpeaking() else voice.speak("Namaste, main Aiva hoon.")
        toast(if (speakOn) "Aiva ab bolega" else "Aiva chup rahega (sirf likhega)")
    }

    private fun toggleLang() {
        voice.lang = if (voice.lang == "hi-IN") "en-IN" else "hi-IN"
        langBtn.text = if (voice.lang == "hi-IN") "हिं" else "EN"
        toast(if (voice.lang == "hi-IN") "Sunne ki bhasha: Hindi" else "Listening language: English")
    }

    private fun toggleVoice() {
        if (voiceMode) {
            voiceMode = false; voice.continuous = false
            voice.stopListening(); voice.stopSpeaking()
            setOrb(0, "Taiyaar hoon"); note("Voice mode band")
        } else {
            voiceMode = true; voice.continuous = true
            note("🎙 Voice mode ON — bolein, main sun raha hoon. Rokne ke liye ⏹ dabayein ya “ruko” bolein.")
            voice.startListening()
        }
        updateAction()
    }

    private fun stopAll() {
        cancelled = true; agent.stop = true
        AgentService.instance?.stopRequested = true
        brain().stop(); voice.stopSpeaking(); job?.cancel()
        pendingAnswer?.complete("nahi")
        note("Roka gaya.")
        if (voiceMode) voice.startListening()
    }

    // ---------------- Messaging ----------------
    private fun onHeard(text: String) {
        val t = text.trim()
        if (pendingAnswer == null && stopWords.matches(t)) { if (voiceMode) toggleVoice(); return }
        if (busy && pendingAnswer == null) { voice.startListening(); return }
        send(t)
    }

    private fun handlePref(t: String): String? {
        val low = t.lowercase()
        if (!Regex("(jawab|answer|reply|replies)").containsMatchIn(low)) return null
        val len = when {
            Regex("(chhota|chota|short|chhote|choti)").containsMatchIn(low) -> 0
            Regex("(lamba|lamb|long|detail|vistar)").containsMatchIn(low) -> 2
            Regex("(normal|beech|medium)").containsMatchIn(low) -> 1
            else -> return null
        }
        prefs.edit().putInt("len", len).apply()
        return when (len) { 0 -> "Theek hai, ab chhote jawab dunga."; 2 -> "Theek hai, ab detail me jawab dunga."; else -> "Theek hai, ab normal lambai ke jawab dunga." }
    }

    private fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val pa = pendingAnswer
        if (pa != null) { userBubble(t); pa.complete(t); return }
        val pc = pendingCorrection
        if (pc != null) {
            pendingCorrection = null
            userBubble(t)
            learn.addChat(pc.first, t, "user")
            aivaBubble("Shukriya! Ab agli baar aisa hi jawab dunga. 🧠")
            return
        }
        if (busy) { toast("Aiva abhi kaam kar raha hai… ek second"); return }
        cancelled = false
        voice.stopSpeaking()
        userBubble(t)
        turns.add(true to t)
        setBusy(true)
        job = scope.launch {
            try {
                val pref = handlePref(t)
                if (pref != null) { aivaSay(pref); return@launch }
                val q = if (mode != 1) agent.quick(t, { s -> askUser(s) }, isLocal()) else null
                if (q != null) { learn.use(t); aivaSay(q); return@launch }
                val problem = brain().ready()
                if (problem != null) { aivaSay(problem); return@launch }
                val wantTask = mode == 2 || (mode == 0 && taskRe.containsMatchIn(t))
                if (wantTask) {
                    if (AgentService.instance == null) {
                        aivaSay("Phone control ke liye pehle Accessibility me Aiva ko ON karein."); return@launch
                    }
                    setOrb(2, "Kaam kar raha hoon…")
                    val res = agent.run(t) { s -> askUser(s) }
                    val ok = !failRe.containsMatchIn(res)
                    if (ok) learn.use(t)
                    val svc = AgentService.instance
                    if (voiceMode) svc?.openApp("Aiva") else svc?.hudDone(res.take(70), ok) { AgentService.instance?.openApp("Aiva") }
                    aivaSay(res, if (ok) Triple(t, res, "task") else null)
                } else {
                    converse(t)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                aivaSay("Kuch gadbad hui: ${e.message}")
            } finally {
                setBusy(false)
            }
        }
    }

    /** Agent ko kisi sawal ka jawab chahiye (haan/nahi ya koi info). */
    private suspend fun askUser(q: String): String {
        aivaSay(q)
        if (q.contains("haan/nahi")) addYesNo()
        val d = CompletableDeferred<String>()
        pendingAnswer = d
        setOrb(1, "Aapke jawab ka intezaar…")
        AgentService.instance?.openApp("Aiva")
        try { return d.await() } finally { pendingAnswer = null }
    }

    private fun aivaSay(text: String, fb: Triple<String, String, String>? = null) {
        aivaBubble(text)
        turns.add(false to text)
        if (turns.size > 14) turns.removeAt(0)
        if (fb != null) addFeedback(fb.first, fb.second, fb.third, if (isLocal()) "offline" else "online")
        finishReply(text)
    }

    private fun finishReply(text: String) {
        if (voiceMode || speakOn) { setOrb(3, "Bol raha hoon…"); voice.speak(text) }
        else setOrb(0, "Taiyaar hoon")
    }

    private suspend fun converse(userText: String) {
        val b = brain()
        setOrb(2, "Soch raha hoon…")
        val wrap = FrameLayout(this).apply {
            background = bg("#24244D", 18); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        wrap.addView(DotsView(this))
        chat.addView(wrap, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; topMargin = dp(8) })
        popIn(wrap, false)
        val tv = aivaBubble("", false)
        scrollDown()
        var revealed = false
        fun reveal() {
            if (revealed) return
            revealed = true
            chat.removeView(wrap)
            tv.visibility = View.VISIBLE
            popIn(tv, false)
        }

        val lenIdx = prefs.getInt("len", 1)
        val maxChars = when (lenIdx) { 0 -> 260; 2 -> 1100; else -> 650 }
        val system = Prompts.persona(memory.summary(), lenIdx)
        val snapshot = turns.toList()
        val examples = if (b is LocalBrain) learn.bestChat(userText, 2) else emptyList()
        val raw = withContext(Dispatchers.Default) {
            try {
                b.chat(system, snapshot, maxChars, examples) { p ->
                    if (!cancelled) runOnUiThread { reveal(); tv.text = Prompts.clean(p); scrollDown() }
                }
            } catch (e: Throwable) { "ERROR:" + (e.message ?: e.javaClass.simpleName) }
        }
        reveal()
        if (cancelled) { tv.text = "(roka gaya)"; return }
        if (raw.isBlank()) { tv.text = "Aiva abhi pichhla jawab khatam kar raha hai. Thodi der baad try karein."; return }
        if (raw.startsWith("ERROR:")) { tv.text = "Maaf karein, jawab nahi bana.\n" + raw.removePrefix("ERROR:").take(200); return }
        var out = Prompts.clean(raw)
        if (b is LocalBrain && out.length > maxChars) out = Prompts.trimToSentence(out)
        if (out.isBlank()) out = "Mujhe samajh nahi aaya, dobara kahenge?"
        tv.text = out
        turns.add(false to out)
        if (turns.size > 14) turns.removeAt(0)
        addFeedback(userText, out, "chat", if (isLocal()) "offline" else "online")
        finishReply(out)
    }

    // ---------------- Model / Settings ----------------
    private fun warmUp() {
        if (!isLocal() || !llm.hasModel()) return
        setOrb(2, "Model load ho raha hai…")
        Thread {
            try {
                llm.load()
                runOnUiThread { setOrb(0, "Taiyaar hoon") }
            } catch (e: Throwable) {
                runOnUiThread {
                    note("Model load nahi hua: ${e.message}\nShayad file galat hai ya phone ke liye bhaari hai.")
                    setOrb(0, "Model problem")
                }
            }
        }.start()
    }

    private fun pickModel() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1)
    }

    private fun segment(opts: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        val chips = mutableListOf<TextView>()
        fun paint(sel: Int) {
            chips.forEachIndexed { k, v -> (v.background as GradientDrawable).setColor(Color.parseColor(if (k == sel) "#7C5CFF" else "#26265A")) }
        }
        opts.forEachIndexed { i, s ->
            val c = chip(s) { paint(i); onPick(i) }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        }
        paint(selected)
        return row
    }

    private fun showLearned() {
        val sb = StringBuilder(learn.counts())
        val a = learn.aliasList()
        if (a.isNotEmpty()) sb.append("\n\nNicknames:\n").append(a.take(10).joinToString("\n"))
        val m = learn.macroGoals()
        if (m.isNotEmpty()) sb.append("\n\nSeekhe hue kaam:\n").append(m.take(10).joinToString("\n"))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("🧠 Aiva ne kya seekha")
            .setMessage(sb.toString())
            .setPositiveButton("Theek hai", null)
            .setNeutralButton("📤 Training data export") { _, _ -> toast(learn.exportJsonl(this)) }
            .setNegativeButton("Sab bhoolo") { _, _ -> learn.clearAll(); refreshQuick(); toast("Seekha hua sab hata diya") }
            .show()
    }

    private fun openSettings() {
        var brainSel = if (isLocal()) 0 else 1
        var provSel = if ((prefs.getString("provider", "gemini") ?: "gemini") == "claude") 1 else 0
        var lenSel = prefs.getInt("len", 1)
        var dlg: AlertDialog? = null

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4))
        }
        fun lab(t: String) = TextView(this).apply {
            text = t; textSize = 12f; setTextColor(Color.parseColor("#B9B6E8")); setPadding(0, dp(12), 0, dp(4))
        }
        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = bg("#26265A", 12)
            setOnClickListener { f() }
            pressAnim()
        }
        val key = EditText(this).apply {
            hint = "API key yahan paste karein"; setText(prefs.getString("apikey", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 14f
        }
        val model = EditText(this).apply {
            hint = "model naam (khaali = default)"; setText(prefs.getString("cloudmodel", ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 14f
        }

        box.addView(lab("DIMAAG (Brain)"))
        box.addView(segment(listOf("📱 Offline", "☁️ Online (tez & smart)"), brainSel) { brainSel = it })
        box.addView(lab("ONLINE PROVIDER"))
        box.addView(segment(listOf("Gemini (free)", "Claude"), provSel) { provSel = it })
        box.addView(key); box.addView(model)
        box.addView(TextView(this).apply {
            text = "Gemini key (free): aistudio.google.com/apikey\nClaude key: console.anthropic.com\nKey sirf aapke phone me save hoti hai."
            textSize = 11f; setTextColor(Color.parseColor("#8E8CB0"))
        })
        box.addView(lab("JAWAB KI LAMBAI"))
        box.addView(segment(listOf("Chhota", "Normal", "Lamba"), lenSel) { lenSel = it })
        box.addView(lab("TOOLS"))
        fun add(v: View) { box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }) }
        add(btn("🧠 Aiva ne kya seekha") { dlg?.dismiss(); showLearned() })
        add(btn("📁 Offline model file chunein") { dlg?.dismiss(); pickModel() })
        add(btn("🔊 Awaaz test") { voice.speak("Namaste, main Aiva hoon. Kya aap meri awaaz sun pa rahe hain?") })
        add(btn("🗣 TTS (awaaz) settings kholo") {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        })
        add(btn("📇 Contacts + Call permission dein") {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 8)
        })
        add(btn("🔧 Safe mode reset") {
            prefs.edit().putBoolean("safe", false).putInt("fails", 0).commit(); llm.reset(); toast("Safe mode band, model dobara load hoga")
        })
        add(btn("🧹 Yaaddasht saaf karo") { memory.clear(); toast("Yaaddasht saaf") })

        dlg = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Aiva Settings")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("brain", if (brainSel == 1) "cloud" else "local")
                    .putString("provider", if (provSel == 1) "claude" else "gemini")
                    .putString("apikey", key.text.toString().trim())
                    .putString("cloudmodel", model.text.toString().trim())
                    .putInt("len", lenSel).apply()
                refreshStatus(); warmUp()
            }
            .setNegativeButton("Band karo", null)
            .create()
        dlg.show()
    }

    // ---------------- Results ----------------
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 7) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (voiceMode) voice.startListening()
            } else {
                voiceMode = false; voice.continuous = false; updateAction()
                note("Mic permission nahi mili, isliye voice mode band hai.")
            }
        } else if (requestCode == 8) {
            val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            toast(if (ok) "Contacts + Call permission mil gayi" else "Call/contacts wale kaam ke liye permission zaroori hai")
        }
    }

    @Deprecated("simple starter")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 3) { voice.onDialogResult(res, data); return }
        if (req != 1 || res != RESULT_OK || data == null) return
        val uri = data.data ?: return
        note("Model copy ho raha hai, thoda wait karein…")
        scope.launch(Dispatchers.IO) {
            try {
                llm.reset()
                contentResolver.openInputStream(uri)!!.use { i ->
                    llm.modelFile.outputStream().use { o -> i.copyTo(o) } }
                prefs.edit().putBoolean("safe", false).putInt("fails", 0).commit()
                withContext(Dispatchers.Main) { note("Model copy ho gaya ✅"); refreshStatus(); warmUp() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { note("Model copy fail: ${e.message}") }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voice.shutdown(); scope.cancel()
    }
}
