package com.example.aiva

object Prompts {
    fun persona(memory: String, len: Int): String {
        val length = when (len) {
            0 -> "Keep replies to 1-2 short sentences."
            2 -> "Give a detailed, helpful answer (up to 8-10 sentences)."
            else -> "Answer in 3-5 clear sentences with useful detail."
        }
        return "You are Aiva, a warm, smart, JARVIS-like voice assistant on the user's Android phone. Talk like a helpful friend. " +
            "Reply in the same language and script as the user's last message: Hinglish (Hindi in English letters) if they write Hinglish, " +
            "Devanagari if they write Devanagari, English if English. $length " +
            "No markdown, no emojis, no bullet lists, never repeat the question. " +
            (if (memory.isNotBlank()) "Known about the user: $memory" else "")
    }

    fun clean(s: String): String =
        s.replace("<end_of_turn>", "").replace("<start_of_turn>", "").replace("<eos>", "")
            .replace(Regex("[*#`]"), "").trim()

    private val defaultSpace = listOf(
        true to "mujhe space ke bare me batao",
        false to "Space yaani antariksh, jahan taare, grah aur galaxies hote hain. Ye itna bada hai ki roshni ko ek galaxy paar karne me hazaaron saal lag jate hain."
    )

    /** Gemma chat format; seekhe hue examples seeds ban kar style sikhate hain. */
    fun chat(system: String, turns: List<Pair<Boolean, String>>, budget: Int, examples: List<Pair<String, String>>): String {
        var used = system.length
        val picked = ArrayList<Pair<Boolean, String>>()
        for (i in turns.indices.reversed()) {
            val t = turns[i].second.take(450)
            if (picked.isNotEmpty() && used + t.length > budget) break
            used += t.length + 30
            picked.add(0, turns[i].first to t)
        }
        while (picked.isNotEmpty() && !picked[0].first) picked.removeAt(0)
        val seeds = ArrayList<Pair<Boolean, String>>()
        seeds.add(true to "hi")
        seeds.add(false to "Namaste! Main Aiva hoon. Bataiye, main aapki kya madad kar sakta hoon?")
        if (examples.isEmpty()) seeds.addAll(defaultSpace)
        else for (e in examples.take(2)) { seeds.add(true to e.first.take(150)); seeds.add(false to e.second.take(300)) }
        val seedLen = seeds.sumOf { it.second.length } + 60
        if (picked.size <= 4 && used + seedLen < budget) picked.addAll(0, seeds)
        val sb = StringBuilder()
        var first = true
        for ((user, text) in picked) {
            if (user) {
                sb.append("<start_of_turn>user\n")
                if (first) sb.append(system).append("\n\n")
                sb.append(text).append("<end_of_turn>\n")
                first = false
            } else {
                sb.append("<start_of_turn>model\n").append(text).append("<end_of_turn>\n")
            }
        }
        sb.append("<start_of_turn>model\n")
        return sb.toString()
    }

    fun trimToSentence(s: String): String {
        val idx = maxOf(s.lastIndexOf('.'), s.lastIndexOf('।'), s.lastIndexOf('?'), s.lastIndexOf('!'))
        return if (idx > s.length / 3) s.substring(0, idx + 1) else s
    }

    fun agentSystem(full: Boolean, memory: String): String {
        val head = "You are Aiva's phone-control brain. You operate an Android phone for the user, step by step, to reach the GOAL. " +
            "Each turn you get the numbered screen elements and your past steps. Reply with EXACTLY ONE JSON object and nothing else.\nActions:\n"
        val core = """{"action":"open_app","name":"WhatsApp"}
{"action":"tap","id":3}
{"action":"type","id":2,"text":"hello","submit":false}
{"action":"scroll","dir":"down"}
{"action":"back"}
{"action":"home"}
{"action":"web_search","query":"..."}
{"action":"call","to":"name or number"}
{"action":"whatsapp","to":"name or number","text":"..."}
{"action":"ask_user","question":"..."}
{"action":"done","summary":"short result"}"""
        val extra = """{"action":"long_press","id":3}
{"action":"swipe","dir":"left"}
{"action":"recents"} {"action":"notifications"} {"action":"screenshot"}
{"action":"wait","seconds":2}
{"action":"youtube","query":"..."} {"action":"maps","query":"..."}
{"action":"sms","to":"name or number","text":"..."}
{"action":"email","to":"a@b.com","subject":"...","body":"..."}
{"action":"alarm","hour":7,"minute":30,"label":"..."} {"action":"timer","seconds":300}
{"action":"flashlight","on":true} {"action":"volume","mode":"up|down|max|mute"}
{"action":"create_file","name":"notes.txt","content":"..."}"""
        val rules = "\nRules: prefer direct actions (web_search, call, whatsapp, sms, email, alarm) over tapping. " +
            "After sms/whatsapp/email opens a draft, tap the Send button. If an action did not change the screen, try something different. " +
            "Ask the user only if essential info is missing. Use done as soon as the goal is complete; write the summary in the user's language style (Hinglish if they use Hinglish). " + memory
        return head + core + (if (full) "\n" + extra else "") + rules
    }
}
