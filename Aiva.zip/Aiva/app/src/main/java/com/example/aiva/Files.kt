package com.example.aiva

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

/** Downloads/Aiva me text file save karna. */
object Files {
    private fun mimeFor(n: String): String = when (n.substringAfterLast('.', "txt").lowercase()) {
        "md" -> "text/markdown"; "csv" -> "text/csv"; "html" -> "text/html"
        "json", "jsonl" -> "application/json"; else -> "text/plain"
    }

    fun saveText(ctx: Context, name: String, content: String): String {
        val safe = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "aiva_note.txt" }
        val fileName = if (safe.contains(".")) safe else "$safe.txt"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(fileName))
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Aiva")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return "File nahi ban payi"
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
                "File ban gayi: Downloads/Aiva/$fileName"
            } else {
                val dir = ctx.getExternalFilesDir(null) ?: return "Storage nahi mila"
                java.io.File(dir, fileName).writeText(content)
                "File ban gayi: ${dir.path}/$fileName"
            }
        } catch (e: Exception) { "File banane me dikkat: ${e.message}" }
    }
}
