plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.aiva"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.aiva"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("aiva-debug.jks")
            storePassword = "aivadebug"
            keyAlias = "aiva"
            keyPassword = "aivadebug"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
}
